import telebot
from telebot import *
import time
from test import send_ble_message, get_latest_data, start_ble_client_in_thread

BOT_TOKEN = "6621637434:AAF5xoH97WhlTs0CkJVenmOVRjUm8mXbZ6A"
bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['update'])
def send_update(message):
    text_to_send = "Update"
    send_ble_message(text_to_send)
    time.sleep(1)  # This is not ideal; consider an asynchronous approach
    latest_ble_data = get_latest_data()

    # Ensure reply_text is always defined
    reply_text = "OOPS something went wrong please try again."
    if latest_ble_data:
        reply_text = f"I Spy With My Little Eye, Your Kid Is Currently: {latest_ble_data}"
    
    bot.reply_to(message, reply_text)

@bot.message_handler(commands=['pet'])
def send_pet(message):
    text_to_send = "Pet"
    send_ble_message(text_to_send)
    time.sleep(1) 
    latest_ble_data = get_latest_data()
    reply_text = "OOPS something went wrong please try again."
    if latest_ble_data:
        print(latest_ble_data)
        try:
            hp = float(latest_ble_data)
            if hp <= 50.00:
                reply_text = f"Current Pet Hp: {latest_ble_data}\nCareful is getting Low"
            elif hp > 50.00:
                reply_text = f"Current Pet Hp: {latest_ble_data}\nStill Healthy"
            elif hp == 0.00:
                reply_text =f"Current Pet Hp: {latest_ble_data}\nYour Kid aint studying for shit, Wack him"
        except ValueError:
            reply_text = "Failed to interpret BLE data as an integer."

    bot.reply_to(message, reply_text)

if __name__ == "__main__":
    start_ble_client_in_thread()
    bot.infinity_polling()
