import asyncio
from bleak import BleakClient
import threading

DEVICE_ADDRESS = "F3:62:74:26:39:14"
WRITE_CHARACTERISTIC_UUID = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
NOTIFY_CHARACTERISTIC_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"

latest_data = None
message_to_send = None

def notification_handler(sender, data):
    global latest_data
    latest_data = data.decode()
    print(f"Received data from BLE: {latest_data}")

async def send_message(client, write_char_uuid, message):
    data = bytes(message, encoding='utf-8')
    await client.write_gatt_char(write_char_uuid, data)
    print(f"Sent data to BLE device: {message}")

async def send_and_listen_ble(address, write_char_uuid, notify_char_uuid):
    global message_to_send
    async with BleakClient(address) as client:
        if await client.is_connected():
            print(f"Connected to BLE device at {address}")
            await client.start_notify(notify_char_uuid, notification_handler)
            print(f"Notifications enabled on {notify_char_uuid}")

            while True:
                if message_to_send:
                    await send_message(client, write_char_uuid, message_to_send)
                    message_to_send = None
                await asyncio.sleep(1)  # Keep alive

        else:
            print(f"Failed to connect to BLE device at {address}")

def run_ble_client():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(send_and_listen_ble(DEVICE_ADDRESS, WRITE_CHARACTERISTIC_UUID, NOTIFY_CHARACTERISTIC_UUID))

def start_ble_client_in_thread():
    ble_thread = threading.Thread(target=run_ble_client, daemon=True)
    ble_thread.start()

def get_latest_data():
    return latest_data

def send_ble_message(text):
    global message_to_send
    message_to_send = text

# Start the BLE client in the background when the script starts
start_ble_client_in_thread()

