=== Compiling ===
Plug in your tinyscreen, and upload "RubberDucky.ino"

=== Web Server Configuration ====
We configured one of our member's Singtel Router to Port Forward HTTP Packets to his XAMPP Web Server.
Since XAMPP Web Server does not support PUT Request, we used the 2 PHP files as handlers, to accept file streams from curl.
Port 80 (HTTP), 3389 (RDP), and 450 (for netcat listener).

portForwarding.png as proof

=== Payloads ===
ncat.exe (a.exe) for Reverse Shell, executable from:
https://nmap.org/ncat/

mimikatz.exe for NTLM hash grabbing, executable from:
https://github.com/ParrotSec/mimikatz/blob/master/x64/mimikatz.exe

NirCmd for Screenshots, executable from:
https://www.nirsoft.net/utils/nircmd.html


